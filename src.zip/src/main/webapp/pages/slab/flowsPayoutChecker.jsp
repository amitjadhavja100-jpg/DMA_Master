<!--flowsPayoutChecker.jsp-->
<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>

<head>

	<title>Flows Payout Checker</title>
	<link rel="stylesheet" href="${pageContext.request.contextPath}/css/slabPayoutConfig/slabConfig.css">

	<script src="${pageContext.request.contextPath}/js/flowsPayoutChecker.js"></script>

	<script>
		const CONTEXT_PATH = "${pageContext.request.contextPath}";
		var userId = localStorage.getItem("user_id");
	</script>

</head>

<body class="bg-light">
	<div class="container-fluid mt-4">

		<h4 class="pageHeading">Flows Payout Checker</h4>

		<div class="filter-row">

			<div class="form-group">
				<label>Product</label>
				<select id="product" class="form-control" onchange="loadSubProducts()">
					<option value="">Select Product</option>
				</select>
			</div>

			<div class="form-group">
				<label>Sub Product</label>
				<select id="subProduct" class="form-control" onchange="loadFlowsChecker()">
					<option value="">Select Sub Product</option>
				</select>
			</div>

		</div>

		<div class="table-responsive mt-4">

			<table class="table table-bordered bg-white text-center">
				<thead class="table-dark">
					<tr>
						<th>ID</th>
						<th>Product</th>
						<th>Sub Product</th>
						<th>Category</th>
						<th>Bucket</th>
						<th>Table Type</th>
						<th>From Date</th>
						<th>To Date</th>
						<th>Version</th>
						<th>Status</th>
						<th>Created By</th>
						<th>Action</th>
					</tr>
				</thead>

				<tbody id="flowsCheckerBody">

				</tbody>
			</table>
		</div>

	</div>

</body>

</html>